import React, { useState, useEffect } from 'react';
import { Sparkles, Star, Zap, Instagram, Twitter, Mail, ChevronDown } from 'lucide-react';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    { name: "Luna M.", review: "OMG these candies literally GLOW! My friends couldn't believe it. Best party snack ever! 🌟", rating: 5 },
    { name: "Alex R.", review: "Galaxy Grape is out of this world! Posted a video and got 10k views overnight 🚀", rating: 5 },
    { name: "Maya S.", review: "I'm obsessed! Stardust Strawberry tastes like magic and looks even better ✨", rating: 5 },
    { name: "Jake T.", review: "Brought these to a rave and everyone was asking where I got them. Pure vibes! 💫", rating: 5 }
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4000);

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(interval);
    };
  }, [testimonials.length]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-black/90 backdrop-blur-md border-b border-pink-500/20' : 'bg-transparent'}`}>
        <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-8 h-8 text-pink-500 animate-pulse" />
            <span className="text-2xl font-bold font-poppins bg-gradient-to-r from-pink-500 via-cyan-400 to-pink-500 bg-clip-text text-transparent animate-pulse">
              GlowSnacks
            </span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            {['Home', 'About', 'Flavors', 'Contact'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="font-roboto hover:text-pink-400 transition-colors duration-300 relative group"
              >
                {item}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-pink-500 to-cyan-400 group-hover:w-full transition-all duration-300"></span>
              </button>
            ))}
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-cyan-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-pink-500/30 rounded-full blur-2xl animate-ping"></div>
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-poppins font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-pink-500 via-cyan-400 to-pink-500 bg-clip-text text-transparent animate-pulse">
              Brighten Your
            </span>
            <br />
            <span className="text-white drop-shadow-2xl">Snack Time</span>
          </h1>
          
          <p className="text-xl md:text-2xl font-roboto mb-8 text-gray-300 max-w-2xl mx-auto">
            The world's first glow-in-the-dark candy — taste the magic.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <button className="group relative px-8 py-4 bg-gradient-to-r from-pink-500 to-cyan-400 rounded-full font-poppins font-semibold text-black hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-pink-500/50">
              <span className="relative z-10">Shop Now ✨</span>
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-pink-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
            
            <button className="px-8 py-4 border-2 border-pink-500 rounded-full font-roboto hover:bg-pink-500/10 transition-all duration-300 hover:scale-105">
              Learn More
            </button>
          </div>

          <div className="animate-bounce">
            <ChevronDown className="w-8 h-8 mx-auto text-pink-400" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="flavors" className="py-20 relative">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-poppins font-bold text-center mb-16 bg-gradient-to-r from-pink-500 to-cyan-400 bg-clip-text text-transparent">
            What Makes Us Glow
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              { icon: Zap, title: "Glow-in-the-Dark Magic", desc: "Real bioluminescent technology that makes your candy actually glow!" },
              { icon: Sparkles, title: "100% Edible Shimmer", desc: "Safe, FDA-approved glitter that sparkles on your tongue" },
              { icon: Star, title: "Cosmic Flavors", desc: "Galaxy Grape, Stardust Strawberry, and Meteorite Mango" }
            ].map((feature, index) => (
              <div key={index} className="group relative p-8 rounded-2xl bg-gradient-to-b from-gray-900/50 to-black/50 border border-pink-500/20 hover:border-pink-500/50 transition-all duration-300 hover:scale-105">
                <div className="absolute inset-0 bg-gradient-to-b from-pink-500/5 to-cyan-400/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative z-10">
                  <feature.icon className="w-12 h-12 text-pink-400 mb-6 group-hover:text-cyan-400 transition-colors duration-300" />
                  <h3 className="text-xl font-poppins font-semibold mb-4 text-white">{feature.title}</h3>
                  <p className="font-roboto text-gray-300 leading-relaxed">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-pink-500/5 to-transparent"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-poppins font-bold mb-8 text-white">
              Born Under the Northern Lights
            </h2>
            <div className="bg-gradient-to-r from-gray-900/80 to-black/80 rounded-3xl p-8 md:p-12 border border-cyan-400/20">
              <p className="text-lg md:text-xl font-roboto text-gray-300 leading-relaxed mb-6">
                GlowSnacks was born in a secret candy laboratory nestled beneath the magical Aurora Borealis. 
                Our founder, Dr. Luna Starweaver, spent years studying the mystical properties of arctic phenomena 
                to create the first-ever edible glow.
              </p>
              <p className="text-lg md:text-xl font-roboto text-gray-300 leading-relaxed">
                Each piece of GlowSnacks candy is infused with the same wonder that lights up the northern sky, 
                bringing a little magic to your everyday snacking experience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-poppins font-bold text-center mb-16 bg-gradient-to-r from-cyan-400 to-pink-500 bg-clip-text text-transparent">
            What Our Glowing Fans Say
          </h2>
          
          <div className="max-w-3xl mx-auto">
            <div className="relative bg-gradient-to-r from-gray-900/50 to-black/50 rounded-3xl p-8 md:p-12 border border-pink-500/20">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
                  ))}
                </div>
                <blockquote className="text-xl md:text-2xl font-roboto text-gray-200 mb-6 italic">
                  "{testimonials[currentTestimonial].review}"
                </blockquote>
                <cite className="text-pink-400 font-poppins font-semibold">
                  — {testimonials[currentTestimonial].name}
                </cite>
              </div>
            </div>
            
            <div className="flex justify-center mt-6 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentTestimonial ? 'bg-pink-500' : 'bg-gray-600 hover:bg-gray-500'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="py-12 border-t border-pink-500/20 bg-gradient-to-t from-pink-500/5 to-transparent">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-6">
              <Sparkles className="w-8 h-8 text-pink-500 animate-pulse" />
              <span className="text-2xl font-bold font-poppins bg-gradient-to-r from-pink-500 via-cyan-400 to-pink-500 bg-clip-text text-transparent">
                GlowSnacks
              </span>
            </div>
            
            <p className="text-gray-400 font-roboto mb-6 text-lg">
              "Snacks That Light Up Your Night" ✨
            </p>
            
            <div className="flex justify-center space-x-6 mb-8">
              <a href="mailto:hello@glowsnacks.com" className="group flex items-center space-x-2 text-gray-400 hover:text-pink-400 transition-colors duration-300">
                <Mail className="w-5 h-5 group-hover:scale-110 transition-transform duration-300" />
                <span className="font-roboto">hello@glowsnacks.com</span>
              </a>
            </div>
            
            <div className="flex justify-center space-x-6">
              {[
                { icon: Instagram, label: "Instagram" },
                { icon: Twitter, label: "Twitter" }
              ].map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  className="w-12 h-12 bg-gradient-to-r from-pink-500/20 to-cyan-400/20 rounded-full flex items-center justify-center hover:from-pink-500 hover:to-cyan-400 hover:text-black transition-all duration-300 group hover:scale-110"
                >
                  <Icon className="w-5 h-5 group-hover:scale-110 transition-transform duration-300" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;